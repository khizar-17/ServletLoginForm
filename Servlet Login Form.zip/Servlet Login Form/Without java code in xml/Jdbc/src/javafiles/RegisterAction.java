package javafiles;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.JdbcUtility;

public class RegisterAction extends ActionClass {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) 
	{
		Connection con=JdbcUtility.getConnection();
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		System.out.println("in register");
	
		Dboperations db=new Dboperations();
		try
		{
			PreparedStatement ps=con.prepareStatement("select * from user where username=? and password=?");
			ps.setString(1,username);
			ps.setString(2,password);
			System.out.println("EXecute");
				if(!db.checkuser(username))
				{
					System.out.println("user alreday exists");
					return "user.exists";
				}
				else
				{
				System.out.println("new users added");
				ps.executeQuery();
				db.registerUser(username, password, 0);
				return "register.success";
				}
	
			
		}catch(Exception e)
			{System.out.println("error:"+e);}
		return null;
		}
}