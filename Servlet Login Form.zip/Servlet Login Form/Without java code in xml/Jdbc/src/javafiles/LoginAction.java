package javafiles;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.JdbcUtility;

public class LoginAction extends ActionClass {
	

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) 
	{
		Connection con=JdbcUtility.getConnection();
		
		HttpSession session=request.getSession();
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		Dboperations db=new Dboperations();
		try
		{
			PreparedStatement ps=con.prepareStatement("select * from user where username=? and password=?");
			
			ps.setString(1,username);
			ps.setString(2,password);
			System.out.println("EXecute");
			if(!db.checkuser(username))
			{
				session.setAttribute("username", username);
				ResultSet rs=ps.executeQuery();
				if(rs.next())
				{
					if(!db.checkstatus(username))
					{
						return "already.login";
					}
					else
					{
						db.changestatus(username, 1);
						return "login.success";
						
						
					}		
				}
				else
				{
					return "login.incorrect";
				}
				
			}else
			{
				return "register.new";
			}
			
		}catch(Exception e)
		{
			System.out.println("error:"+e);
		}
			
	return null;
	}
}
