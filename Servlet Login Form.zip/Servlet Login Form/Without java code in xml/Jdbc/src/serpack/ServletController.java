package serpack;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.imageio.stream.FileImageInputStream;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javafiles.ActionClass;


public class ServletController extends HttpServlet {
	Properties prop;
	
	
	@Override
	public void init(ServletConfig config) throws ServletException 
	{
		prop=new Properties();
		
		String path=config.getInitParameter("config");
		String realpath=config.getServletContext().getRealPath(path);
		System.out.println(realpath);
		try
		{
			prop.load(new FileInputStream(realpath));
			
			//System.out.println("login success");
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	
	
	
	
	
	}
	
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			
		String name=request.getParameter("id");
			System.out.println(name);
			//System.out.println(prop.getProperty("login"));
			
	/*		String realname=prop.getProperty(name);
			System.out.println(realname);
			*/
			
			ActionClass ac=(ActionClass) Class.forName(prop.getProperty(name)).newInstance();
			
			
			String result=ac.execute(request, response);
			System.out.println("am here:"+result);
			
			RequestDispatcher rs=request.getRequestDispatcher(prop.getProperty(result));
			
			rs.forward(request, response);
			
			
			
			
			
		/*	System.out.println("creating object");
			String name=request.getParameter("id");
			System.out.println("id:"+name);
			String realname=prop.getProperty(name);
			System.out.println(realname);
			ActionClass ac=(ActionClass) Class.forName(realname).newInstance();
			System.out.println("object"+ac);
			String result=ac.execute(request, response);
			System.out.println("result");
			RequestDispatcher rd=request.getRequestDispatcher(prop.getProperty(result));
			rd.forward(request, response);*/
		} catch (Exception e) {
		System.out.println("Error:"+e);
		}
	
		
		
	
	}

}
