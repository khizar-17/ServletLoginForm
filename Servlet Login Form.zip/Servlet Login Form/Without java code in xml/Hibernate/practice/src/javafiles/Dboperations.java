package javafiles;

import java.sql.*;

import database.JdbcUtility;
import sun.tools.jar.Main;

public class Dboperations {
PreparedStatement ps;
	ResultSet rs;
	public boolean checkuser(String uname)
	{
		
		Connection con=JdbcUtility.getConnection();
		try
		{
			 ps=con.prepareStatement("select * from user where username=?");
			ps.setString(1,uname);
			rs=ps.executeQuery();
			if(rs.next())
			{
				return false;
			}
			else
			{
				return true;
			}
			
					
		}catch(Exception e)
		{
			System.out.println("error:"+e);
		}
		return false;
		
		
	}
	public boolean checkstatus(String uname)
	{
		Connection con=JdbcUtility.getConnection();
		try
		{
			ps=con.prepareStatement("select status from user where username=?");
			ps.setString(1,uname);
			rs=ps.executeQuery();		
			rs.next();
			if(rs.getInt(1)==1)
			{
				return false;
			}
			else
			{
				return true;
			}
			
			
			
		}catch(Exception e)
		{
			System.out.println("error:"+e);
		}
		
		
		
		return false;
	}
	public void changestatus(String uname,int status){
		try{
			Connection con=JdbcUtility.getConnection();
			ps=con.prepareStatement("update user set status=? where username=?");
			ps.setInt(1, status);
			ps.setString(2, uname);
			ps.executeUpdate();
			JdbcUtility.closeConnection(null);
		}
		catch(Exception e){
			JdbcUtility.closeConnection(e);
		}
	}
	public void registerUser(String uname,String upass,int status){
		try{
			Connection con=JdbcUtility.getConnection();
			ps=con.prepareStatement("insert into user values (?,?,?)");
			ps.setString(1, uname);
			ps.setString(2, upass);
			ps.setInt(3, status);
			ps.executeUpdate();
			JdbcUtility.closeConnection(null);
		}
		catch(Exception e){
			JdbcUtility.closeConnection(e);
		}
	}
	public static void main(String[] args) {
		Dboperations db=new Dboperations();
		db.registerUser("mano", "karan", 0);
	}
	
}
