package javafiles;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutAction extends ActionClass{
@Override
public String execute(HttpServletRequest request, HttpServletResponse response) {
	
	HttpSession session=request.getSession();
	HiberOperations hb=new HiberOperations();
	String uname=session.getAttribute("username").toString();
	System.out.println(uname);
	if(uname!=null)
	{
		hb.changestatus(uname, 0);
		return "logout.success";
	}
	return null;

}
}
