package javafiles;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;

import database.HiberUtility;
import database.JdbcUtility;

public class LoginAction extends ActionClass 
{
	
	
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) 
		{
		HttpSession session=request.getSession();
		HiberOperations hb=new HiberOperations();
		String username=request.getParameter("uname");
		String password=request.getParameter("upass");
		System.out.println(username);
		System.out.println(password);
		
		try
			{
			
				if(hb.checkUserAndPassword(username, password))
					{
					System.out.println("you are in");
						if(hb.checkstatus(username))
							{
							hb.changestatus(username, 1);
							session.setAttribute("username",username);
							return "login.success";
							}
						else
							{
						System.out.println("Login Already Login.AlreadyLogin");
						return "already.Login";
							}
				
					}
				else
				{
					return "login.incorrect";
				}
				}catch(Exception e)
				{
				}
		return "register.new";
		
			

		}	
}
